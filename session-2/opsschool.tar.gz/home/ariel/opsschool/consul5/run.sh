#!/bin/bash
BASE=/opt/consul
PIDFILE=$BASE/consul.pid
IP=`hostname -i`
DC="opsschool-il"
DATADIR=$BASE/datadir
CONFIGDIR=$BASE/config
UIDIR=$BASE/ui
consul agent -server -bootstrap -pid-file=$PIDFILE -client=$IP -ui-dir=$UIDIR -dc=$DC -data-dir $DATADIR -config-dir $CONFIGDIR
