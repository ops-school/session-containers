#!/bin/bash
BASE=/opt/consul
PIDFILE=$BASE/consul.pid
IP=`hostname -i`
DC="opsschool-il"
DATADIR=$BASE/datadir
CONFIGDIR=$BASE/config
UIDIR=$BASE/ui
MASTER="172.17.0.4"
consul agent -server -join $MASTER -pid-file=$PIDFILE -client=$IP -ui-dir=$UIDIR -dc=$DC -data-dir $DATADIR -config-dir $CONFIGDIR
